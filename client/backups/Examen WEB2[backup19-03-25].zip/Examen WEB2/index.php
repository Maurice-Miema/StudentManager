<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.index.css">
    <script src="script.js" defer></script>
    <title>Home Page</title>
</head>
<body>
    <div class="canvas index">
        <header>
            <h3 class="mn-box left-side">app<span class="Academia">academia</span></h3>
            <div class="mn-box right-side">
                <div class="_username">Jonathan Dondwa</div>
                <!-- <div class="_userprofil"><img src="_icons/userprofil.svg" alt=""></div> -->
            </div>
        </header>
        <section>
            <?php include "_admin/home.php";?>
        </section>
    </div>
</body>
</html>