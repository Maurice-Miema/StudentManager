<div class="main home">
    <h2>Menu Applications</h2>
    <menu>
        <div class="up-side">
            <div class="filters">
                <div class="_filter_slider">
                    <div class="_slider"></div>
                </div>
                <div class="_filters">
                    <div class="_fltby _all">Tout</div>
                    <div class="_fltby _professors">Professeurs</div>
                    <div class="_fltby _students">Étudiants</div>
                </div>
            </div>
        </div>
        <div class="low-side">
            <div class="apps">
                <div class="app box1">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box2">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box3">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box4">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box5">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box6">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box7">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box8">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box9">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box10">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box11">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
                <div class="app box12">
                    <div class="_icon"></div>
                    <div class="_appname"></div>
                </div>
            </div>
        </div>
    </menu>
</div>